export const API_BASE_URL = 'https://fe-interview-project-backend.accounts-a35.workers.dev/api';

export const GET_MANUFACTURERS = 'manufacturers';
export const GET_SERVICES = 'services';

export const POST_VALIDATE_COUPON = 'validate-promo-code';
export const POST_CONTACT = 'contact';
