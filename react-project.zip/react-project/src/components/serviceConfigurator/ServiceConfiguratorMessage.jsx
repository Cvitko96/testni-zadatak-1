import React from 'react';

import ToolsIcon from '../../assets/icons/tools-icon.svg';
import { Button } from '../buttons/Button';

export const ServiceConfiguratorMessage = ({ title, text, icon, buttonText, next }) => {
  return (
    <div className='service-configurator-initiate'>
      <img className='service-configurator-initiate__icon' src={icon} alt='tools-icon' />
      <h2 className='h2 h2--bold color-primary margin-0'>{title}</h2>
      <p className='margin-0'>{text}</p>
      {buttonText && (
        <Button onClick={next} className='button-primary'>
          Pokreni konfigurator
        </Button>
      )}
    </div>
  );
};
