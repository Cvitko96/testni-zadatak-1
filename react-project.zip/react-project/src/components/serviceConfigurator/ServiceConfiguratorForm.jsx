import React, { useEffect, useRef, useState } from 'react';

import { Button } from '../buttons/Button';

import CheckMarkIcon from '../../assets/icons/checkmark-icon.svg';
import CloseIcon from '../../assets/icons/close-icon.svg';
import { getManufacturers, getServices, validateCoupon } from '../service/ServiceConfiguratorService';

export const ServiceConfiguratorForm = ({
  selectedManufacturer,
  selectedServices,
  currentStep,
  setSelectedManufacturer,
  setSelectedServices,
  calculateServicePrice,
  couponData,
  setCouponData,
  nameRef,
  emailRef,
  phoneRef,
  noteRef,
  next,
}) => {
  // const servicePrice = useMemo(calculatePrice, [selectedServices, services]);
  const servicePrice = calculateServicePrice();

  const [couponOpen, setCouponOpen] = useState(false);
  const [couponText, setCouponText] = useState('');

  const [emailIsInvalid, setEmailIsInvalid] = useState(false);
  const [servicesIsInvalid, setServicesIsInvalid] = useState(false);

  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  const [manufacturers, setManufacturers] = useState([]);
  const [services, setServices] = useState([]);

  const [loading, setLoading] = useState({
    manufacturers: false,
    services: null,
  });

  const [error, setError] = useState({
    manufacturers: false,
    services: null,
  });

  //fetching data
  useEffect(() => {
    const fetchManufacturers = async () => {
      try {
        setLoading((prevState) => ({ ...prevState, manufacturers: true }));
        const response = await getManufacturers();
        setManufacturers(response);
      } catch (error) {
        setError((prevState) => ({ ...prevState, manufacturers: error.message || 'Greška prilikom dohvata podataka.' }));
      } finally {
        setLoading((prevState) => ({ ...prevState, manufacturers: false }));
      }
    };

    const fetchServices = async () => {
      try {
        setLoading((prevState) => ({ ...prevState, services: true }));
        const response = await getServices();
        setServices(response);
      } catch (error) {
        setError((prevState) => ({ ...prevState, services: error.message || 'Greška prilikom dohvata podataka.' }));
      } finally {
        setLoading((prevState) => ({ ...prevState, services: false }));
      }
    };

    fetchManufacturers();
    fetchServices();
  }, []);

  // Focus coupon input on open
  const couponInputRef = useRef(null);
  useEffect(() => {
    if (couponOpen && couponInputRef.current) {
      couponInputRef.current.focus();
    }
  }, [couponOpen]);

  const confirmCoupon = async (coupon) => {
    const value = coupon.trim();
    if (value) {
      try {
        const response = await validateCoupon(value);
        console.log(response);
        setCouponData(response);
        setCouponText('');
      } catch (error) {
        setError((prevState) => ({ ...prevState, coupon: 'Kupon je nevažeći' }));
      }
    }
  };

  const validateForm = () => {
    let formIsValid = true;

    //validate services
    if (!selectedServices.length) {
      setServicesIsInvalid(true);
      formIsValid = false;
    } else setServicesIsInvalid(false);

    //validate email
    const enteredEmail = emailRef.current.value;
    const emailIsValid = emailRegex.test(enteredEmail);
    if (!emailIsValid) {
      setEmailIsInvalid(true);
      formIsValid = false;
    } else setEmailIsInvalid(false);

    if (formIsValid) return true;
    return false;
  };

  const handleSubmitForm = (event) => {
    event.preventDefault();
    if (validateForm()) {
      next();
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
    }
  };

  const handleServiceChange = (event, service) => {
    const { checked } = event.target;

    if (checked) setSelectedServices((prevState) => [...prevState, service]);
    else setSelectedServices((prevState) => prevState.filter((item) => item !== service));
  };

  const removeCoupon = () => {
    console.log('remove');
    setError((prevState) => ({ ...prevState, coupon: null }));
    setCouponData({});
  };

  return (
    <form className={`form ${currentStep === 3 ? 'hide' : ''}`} onKeyDown={handleKeyDown} onSubmit={handleSubmitForm}>
      <h4 className='h4 h4--bold color-primary margin-bottom-1'>Odaberite proizvođača vašeg vozila</h4>
      <div className='input-selection margin-bottom-1'>
        {!loading.manufacturers ? (
          manufacturers.map((manufacturer) => {
            return (
              <div key={manufacturer.id}>
                <label>
                  <input
                    required
                    checked={selectedManufacturer.id === manufacturer.id}
                    onChange={() => setSelectedManufacturer(manufacturer)}
                    type='radio'
                    value={manufacturer}
                    name='manufacturer'
                  />
                  <span className='margin-left-1'>{manufacturer.name}</span>
                </label>
              </div>
            );
          })
        ) : (
          <div className='h6'>
            <span>Loading...</span>
          </div>
        )}
        {error.manufacturers && (
          <div className='h6'>
            <span>{error.manufacturers}</span>
          </div>
        )}
      </div>

      <h4 className='h4 h4--bold color-primary margin-bottom-1'>Odaberite jednu ili više usluga koju trebate</h4>
      <div className='input-selection services margin-bottom-1'>
        {!loading.services ? (
          services.map((service) => {
            return (
              <div key={service.id}>
                <label>
                  <input
                    type='checkbox'
                    value={service}
                    checked={selectedServices.includes(service)}
                    onChange={(event) => handleServiceChange(event, service)}
                    name='service'
                  />
                  <span className='margin-left-1'>
                    {service.name} <span className='color-primary'>({service.price}€)</span>
                  </span>
                </label>
              </div>
            );
          })
        ) : (
          <div className='h6'>
            <span>Loading...</span>
          </div>
        )}
        {error.manufacturers && (
          <div className='h6'>
            <span>{error.services}</span>
          </div>
        )}
      </div>

      <div className='margin-bottom-2 form__price relative'>
        <div>
          <span className='h4 margin-right-1'>ukupno:</span>
          <span className='h4 h4--bold color-primary'>{servicePrice.toFixed(2)}€</span>
        </div>
        <div>
          {couponOpen ? (
            <div>
              <div className='flex-gap-1'>
                <div className='input'>
                  <input
                    ref={couponInputRef}
                    placeholder='Unesi kod'
                    className='h5 input__field color-base-100'
                    type='text'
                    value={couponText}
                    onChange={(e) => setCouponText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && confirmCoupon(couponText)}
                  />
                </div>

                <Button className='button-primary icon' onClick={() => confirmCoupon(couponText)}>
                  <img className='button-primary__icon' src={CheckMarkIcon} alt='' />
                </Button>
              </div>
              {couponData.code ? (
                <div className='flex-column flex-gap-1 margin-top-1'>
                  <Button className='fit-content button-tertionary'>
                    <span className='h6'>{couponData.code}</span>
                    <img className='pointer' onClick={() => removeCoupon()} src={CloseIcon} alt='' />
                  </Button>
                </div>
              ) : (
                <span className='margin-left-1 h6 color-error'>{error.coupon}</span>
              )}
            </div>
          ) : (
            <span onClick={() => setCouponOpen(true)} className='h5 color-primary pointer'>
              Imam kupon
            </span>
          )}
        </div>
        <div className='form__error-message h6'>{servicesIsInvalid && <span>Molim Vas izaberite barem jednu uslugu!</span>}</div>
      </div>

      <h3 className='h4 h4--bold color-primary margin-bottom-1'>Vaši podaci</h3>
      <section className='user-data margin-bottom-3'>
        <div className='user-data__row'>
          <div className='user-data__field'>
            <label className='user-data__label h6 color-base-100 margin-left-1'>Ime i prezime</label>
            <input
              required
              ref={nameRef}
              placeholder='Unesite ime i prezime'
              className='h5 user-data__input input__field color-base-100'
              type='text'
            />
          </div>

          <div className='user-data__field'>
            <label className='user-data__label h6 color-base-100 margin-left-1'>Broj telefona</label>
            <input
              required
              ref={phoneRef}
              placeholder='Unesite broj telefona'
              className='h5 user-data__input input__field color-base-100'
              type='text'
            />
          </div>
        </div>

        <div className='user-data__field relative'>
          <label className='user-data__label h6 color-base-100 margin-left-1'>Email adresa</label>
          <input
            ref={emailRef}
            placeholder='Unesite email adresu'
            className={`h5 user-data__input input__field color-base-100 ${emailIsInvalid ? 'error' : ''}`}
            // type='email'
          />
          <div className='form__error-message h6'>{emailIsInvalid && <span>Molim Vas unesite ispravan email!</span>}</div>
        </div>

        <div className='user-data__field'>
          <label className='user-data__label h6 color-base-100 margin-left-1'>Napomena (opcionalno)</label>
          <input ref={noteRef} placeholder='Unesite napomenu' className='h5 user-data__input input__field color-base-100' type='text' />
        </div>
        <Button type={'submit'} className='button-primary margin-top-1'>
          Dalje
        </Button>
      </section>
    </form>
  );
};
