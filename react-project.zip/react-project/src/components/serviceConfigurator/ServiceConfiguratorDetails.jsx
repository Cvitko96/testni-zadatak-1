import React from 'react';
import { Button } from '../buttons/Button';
import { validateContact } from '../service/ServiceConfiguratorService';

export const ServiceConfiguratorDetails = ({
  currentStep,
  selectedManufacturer,
  selectedServices,
  couponData,
  nameRef,
  emailRef,
  phoneRef,
  noteRef,
  calculateBasePrice,
  calculateDiscountAmount,
  calculateServicePrice,
  back,
  next,
}) => {
  const submitConfigurator = async () => {
    const manufacturerId = selectedManufacturer.id;
    const serviceIds = selectedServices.map((service) => service.id);
    const promoCode = couponData.code;

    const request = {
      manufacturerId,
      serviceIds,
      promoCode,
      fullName: nameRef.current.value,
      email: emailRef.current.value,
      phoneNumber: phoneRef.current.value,
      note: noteRef.current.value,
    };

    try {
      await validateContact(request);
      next();
    } catch (error) {
      console.log('Error: ', error);
      alert('Došlo je do pogreške. Molimo pokušajte kansije');
    }
  };
  return (
    <>
      {currentStep === 3 && (
        <>
          <h4 className='h4 h4--bold color-primary margin-bottom-1'>Pregled i potvrda vašeg odabira</h4>

          <p className='h5 margin-bottom-2'>
            Molimo vas da još jednom pregledate i potvrdite podatke. Ukoliko želite promijeniti neki od podataka, vratite se na prethodni korak. Kada
            ste provjerili ispravnost svojih podataka, za slanje upita na servis pritisnite gumb “Pošalji”.
          </p>

          <section className='data-view margin-bottom-2 h5'>
            <h4 className='h4 h4--bold color-primary margin-bottom-1'>Model vozila</h4>
            <p className='margin-bottom-2'>{selectedManufacturer.name}</p>

            <h4 className='h4 h4--bold color-primary margin-bottom-1'>Odabrane usluge</h4>
            {selectedServices.map((service) => (
              <div key={service.id} className='data-view__services'>
                <span>{service.name}</span>
                <span>{service.price.toFixed(2)} €</span>
              </div>
            ))}

            {couponData.code && (
              <div className='data-view__price'>
                <span className='color-base-200'>Popust {couponData.discountPercentage}%:</span>
                <span>-{calculateDiscountAmount(calculateBasePrice()).toFixed(2)} €</span>
              </div>
            )}
            <div className='data-view__price margin-bottom-2'>
              <span className='color-base-200'>Ukupno:</span>
              <span className='color-primary h5--medium'>{calculateServicePrice().toFixed(2)} €</span>
            </div>

            <h4 className='h4 h4--bold color-primary margin-bottom-1'>Kontakt podaci</h4>

            <div className='data-view__contact-info'>
              <div className='contact-info__item'>
                <p className='contact-info__label color-base-200'>Ime i prezime:</p>
                <span>{nameRef.current.value}</span>
              </div>
              <div className='contact-info__item'>
                <p className='contact-info__label color-base-200'>Email adresa:</p>
                <span>{emailRef.current.value}</span>
              </div>
              <div className='contact-info__item'>
                <p className='contact-info__label color-base-200'>Broj telefona:</p>
                <span>{phoneRef.current.value}</span>
              </div>
              <div className='contact-info__item'>
                <p className='contact-info__label color-base-200'>Napomena:</p>
                <span>{noteRef.current.value}</span>
              </div>
            </div>
          </section>

          <div className='flex-gap-2'>
            <Button onClick={back} className='button-secondary'>
              Nazad
            </Button>

            <Button onClick={submitConfigurator} className='button-primary flex-grow-1'>
              Pošalji
            </Button>
          </div>
        </>
      )}
    </>
  );
};
