import React, { useRef, useState } from 'react';
import { ServiceConfiguratorDetails } from './ServiceConfiguratorDetails';
import { ServiceConfiguratorForm } from './ServiceConfiguratorForm';

export const ServiceConfiguratorComponent = ({ manufacturers, services, currentStep, next, back }) => {
  const [selectedManufacturer, setSelectedManufacturer] = useState('');
  const [selectedServices, setSelectedServices] = useState([]);
  const [couponData, setCouponData] = useState({});

  const nameRef = useRef(null);
  const phoneRef = useRef(null);
  const emailRef = useRef(null);
  const noteRef = useRef(null);

  //calculate price methods
  const calculateBasePrice = () => {
    return selectedServices.reduce((sum, service) => sum + service.price, 0);
  };
  const calculateDiscountAmount = (basePrice) => {
    const discountPercentage = couponData.code ? couponData.discountPercentage : 0;
    return basePrice * (discountPercentage / 100);
  };
  const calculateServicePrice = () => {
    const basePrice = calculateBasePrice();
    const discountAmount = calculateDiscountAmount(basePrice);
    return basePrice - discountAmount;
  };

  return (
    <>
      <h2 className='h2 h2--bold margin-bottom-2'>Konfigurator Servisa</h2>

      <ServiceConfiguratorForm
        manufacturers={manufacturers}
        services={services}
        calculateServicePrice={calculateServicePrice}
        couponData={couponData}
        currentStep={currentStep}
        setCouponData={setCouponData}
        selectedManufacturer={selectedManufacturer}
        selectedServices={selectedServices}
        setSelectedManufacturer={setSelectedManufacturer}
        setSelectedServices={setSelectedServices}
        nameRef={nameRef}
        emailRef={emailRef}
        phoneRef={phoneRef}
        noteRef={noteRef}
        next={next}
      />

      <ServiceConfiguratorDetails
        currentStep={currentStep}
        selectedManufacturer={selectedManufacturer}
        selectedServices={selectedServices}
        couponData={couponData}
        nameRef={nameRef}
        emailRef={emailRef}
        phoneRef={phoneRef}
        noteRef={noteRef}
        calculateBasePrice={calculateBasePrice}
        calculateDiscountAmount={calculateDiscountAmount}
        calculateServicePrice={calculateServicePrice}
        back={back}
        next={next}
      />
    </>
  );
};
