import React from 'react';

export const Header = () => {
  return (
    <div className='header-primary'>
      <span className='h2 h2--bold'>Konfigurator servisa</span>
      <span className='h5'>Izračunajte trošak servisa</span>
    </div>
  );
};
