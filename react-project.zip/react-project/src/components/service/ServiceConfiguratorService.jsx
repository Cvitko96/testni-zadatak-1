import { GET_MANUFACTURERS, GET_SERVICES, POST_CONTACT, POST_VALIDATE_COUPON } from '../../common/constants/constants';
import { fetchData } from '../../common/service/apiService';

export const getManufacturers = () => fetchData(GET_MANUFACTURERS);
export const getServices = () => fetchData(GET_SERVICES);

export const validateCoupon = (couponcode) => fetchData(`${POST_VALIDATE_COUPON}/${couponcode}`, 'POST');
export const validateContact = (contact) => fetchData(POST_CONTACT, 'POST', contact);
