import React from 'react';

export const Button = ({ children, type, className, onClick }) => {
  return (
    <button onClick={onClick} className={` h4 ${className}`} type={type || 'button'}>
      {children}
    </button>
  );
};
