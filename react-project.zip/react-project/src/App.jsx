import { Header } from './components/Header';
import { ServiceConfiguratorContainer } from './containers/ServiceConfiguratorContainer';
import './sass/main.scss';

function App() {
  return (
    <>
      <Header />
      <ServiceConfiguratorContainer />
    </>
  );
}

export default App;
