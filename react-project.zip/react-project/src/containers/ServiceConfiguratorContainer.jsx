import React, { useEffect, useState } from 'react';
import { ServiceConfiguratorMessage } from '../components/serviceConfigurator/ServiceConfiguratorMessage';
import { ServiceConfiguratorComponent } from '../components/serviceConfigurator/ServiceConfiguratorComponent';

import ToolsIcon from '../assets/icons/tools-icon.svg';
import SuccessIcon from '../assets/icons/success-icon.svg';

export const ServiceConfiguratorContainer = () => {
  const [currentStep, setCurrentStep] = useState(1);

  const title1 = 'Vaša prijava je uspješno poslana';
  const title2 = 'Konfigurator Servisa';

  const text1 = 'Pošaljite upit za servis svog vozila pomoću našeg konfiguratora i naš stručan tim će vam se javiti u najkraćem mogućem roku.';
  const text2 = 'Vaša prijava je uspješno poslana i zaprimljena. Kontaktirat ćemo vas u najkraćem mogućem roku. Hvala vam!';

  const nextStep = () => {
    setCurrentStep((prevState) => prevState + 1);
  };

  const previousStep = () => {
    setCurrentStep((prevState) => prevState - 1);
  };

  return (
    <>
      <div className='service-configurator'>
        {currentStep === 1 && (
          <ServiceConfiguratorMessage icon={ToolsIcon} title={title1} text={text1} buttonText={'Pokreni konfigurator'} next={nextStep} />
        )}
        {(currentStep === 2 || currentStep === 3) && <ServiceConfiguratorComponent currentStep={currentStep} next={nextStep} back={previousStep} />}
        {currentStep === 4 && <ServiceConfiguratorMessage icon={SuccessIcon} title={title2} text={text2} />}
      </div>
    </>
  );
};
